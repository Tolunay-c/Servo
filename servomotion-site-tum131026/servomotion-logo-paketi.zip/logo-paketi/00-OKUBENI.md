# ServoMotion SM — logo paketi

Eylül 2026 · Oktay Otomasyon Elektronik Mühendislik San. ve Tic. A.Ş.

---

## Kurgu

İşaret, özgün SM monogramının ızgaraya oturtulmuş hâlidir. Üç kural:

1. **Tek eğim — 19,07°.** Her çizgi, her uç bu açıda. (1907 · sessiz bir imza.)
2. **Bütün beyaz boşluklar eşit — 0,130 H.** Yataydaki yarıklar da, eğik kanallar da.
   Ölçü daima dik mesafedir; bu yüzden eğik kanalların yatay açıklığı `0,130 H ÷ cos 19,07°`.
3. **Bütün eğik siyah şeritler eşit — 0,3308 H.**

S'in yatay ekseni işaretin tam merkezinde. Merkez + eşit boşluk şartı, üst kol ile
alt sol bloğun kalınlığını kendiliğinden eşitliyor (0,3015 H).

Ölçülen şerit boyları: S'in iki sütunu 0,6190 H (eşit), M'in 2. ve 3. paraleli
1,0581 H (eşit). Kanıt diyagramları `05-olcum-kontrol/` içinde.

---

## Klasörler

| Klasör | İçerik |
|---|---|
| `01-isaret/` | İşaret tek başına — antrasit, siyah, beyaz, sarı. SVG + saydam PNG. |
| `02-yatay-kilit/` | İşaret + ServoMotion kelime markası. Tek ton ve iki ton. |
| `03-web/` | Siteye gömülen sürüm, favicon seti, apple-touch, webmanifest, Poppins alt kümesi. |
| `04-alternatif-ayarlar/` | E (açık ritim) ve F (sıkı ızgara) ayarları — aynı kurgu, farklı boşluk/gövde oranı. |
| `05-olcum-kontrol/` | Boşluk ve boy eşitliğinin ölçüm diyagramları. |
| `06-urun-gorseli/` | Kutu fotoğrafı, yeni logo işlenmiş hâli. |
| `07-eski-denemeler/` | Reddedilen çatal-M yönü (A/B/C). Arşiv. |
| `08-animasyon/` | Lazer taramalı açılış animasyonu — SVG, MP4, GIF. `00-onizleme.html` hepsini bir arada gösterir. |

Kullanılan ayar: **D** (özgün kütle). E ve F arşivde duruyor.

---

## Renkler

| | HEX | Not |
|---|---|---|
| Antrasit | `#383E42` | RAL 7016. Ana kurumsal ton. |
| Açık ton | `#7C858B` | İki tonlu kilitte "Servo" için. |
| Mürekkep | `#1A2230` | Koyu zeminli web sürümü. |
| Sarı | `#FFD400` | Koyu zemin üzerinde işaret. |
| Siyah | `#000000` | Tek renk baskı. |
| Beyaz | `#FFFFFF` | Koyu zemin, tek renk. |

Kutu baskısında: işaret ve "Motion" `#141414`, "Servo" `#5F6267`.

---

## Kelime markası

Poppins. **Servo** Regular (400), **Motion** Bold (700). Harf aralığı `.005em`.
İki tonlu kullanımda Servo açık, Motion koyu.

`03-web/fonts/` içindeki woff2 dosyaları yalnızca "ServoMotion" ve "CorePrecisor"
harflerini içeren alt kümedir (~1 KB). Tam font gerekiyorsa Google Fonts'tan Poppins.

---

## Kullanım kuralları

- İşaretin çevresinde en az **0,13 H** (bir boşluk genişliği) boş alan bırakın.
- Eğimi değiştirmeyin, yatay/dikey esnetmeyin, gölge veya kontur eklemeyin.
- Menüde ve küçük boyutlarda işaret tek başına kullanılır; 16 px yüksekliğe kadar okunur.
- Yatay kilit, işaret yüksekliği 24 px'in altına inmemek kaydıyla kullanılır.
- Sarı zemin üzerinde işaret antrasit veya siyah; koyu zemin üzerinde sarı veya beyaz.

---

## Sitede nereye bağlı

`assets/sm.svg` her sayfanın menüsüne satır içi gömülü (790 bayt, `currentColor`).
Favicon seti kökte. Değişiklik gerekirse `03-web/` içindekileri aynı adlarla değiştirmek yeterli.

---

## Animasyon

Işın soldan sağa tarıyor, işaret arkasında beliriyor; ışın geçtikten sonra kelime
markası soldan kayarak giriyor. Tek döngü **3,4 saniye**, sonsuz tekrar.

| | |
|---|---|
| 0,14 – 1,43 sn | tarama, işaret beliriyor |
| 1,22 – 1,80 sn | kelime markası giriyor |
| 1,80 – 2,99 sn | durağan kare |
| 2,99 – 3,28 sn | sönümleme, başa dönüş |

Dört zemin: koyu (sarı ışın), açık (kırmızı ışın), sarı, saydam.

- **SVG** — web için birincil sürüm, 9,5 KB, `<img src="...">` ile çalışır, JS gerekmez.
- **MP4** — 1600×428, 30 fps, ~80 KB. Sunum ve sosyal medya.
- **GIF** — 900 px, 25 fps, ~270 KB. E-posta imzası ve eski ortamlar; mümkünse SVG/MP4 tercih edin.

Sitede kullanılacaksa `prefers-reduced-motion` açık olan ziyaretçilere durağan
işaretin gösterilmesi doğru olur.

### Menü logosu hareketi

Site menüsündeki logo, her sayfa açılışında bir kez oynuyor: beyaz ışın soldan sağa
geçiyor, işaret arkasında beliriyor, hemen ardından kelime markası soldan kayarak giriyor.
Toplam **0,82 sn**. `servomotion-menu-logosu.gif` bunun kaydı.

Teknik: satır içi SVG'ye `clip-path` tabanlı CSS animasyonu. JavaScript yok, ek istek yok.
`prefers-reduced-motion: reduce` açık olan ziyaretçilerde animasyon devre dışı, logo
doğrudan son hâliyle görünüyor.

Kurallar `assets/brandfont.css` içinde (`smkPerde`, `smkIsin`, `smkKw`). Kapatmak için
o üç kuralı silmek yeterli — işaret olduğu gibi kalır.
